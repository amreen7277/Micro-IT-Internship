let taskList = JSON.parse(localStorage.getItem("tasks")) || [];
function displayTasks() {
  const ul = document.getElementById("taskList");
  ul.innerHTML = "";
  taskList.forEach((task, index) => {
    const li = document.createElement("li");
    li.innerHTML = \`
      <span style="text-decoration:${task.done ? 'line-through' : 'none'}">${task.name}</span>
      <div>
        <button onclick="toggleTask(${index})">${task.done ? 'Undo' : 'Done'}</button>
        <button onclick="deleteTask(${index})">Delete</button>
      </div>
    \`;
    ul.appendChild(li);
  });
  localStorage.setItem("tasks", JSON.stringify(taskList));
}
function addTask() {
  const input = document.getElementById("taskInput");
  if (input.value.trim() === "") return;
  taskList.push({ name: input.value, done: false });
  input.value = "";
  displayTasks();
}
function deleteTask(index) {
  taskList.splice(index, 1);
  displayTasks();
}
function toggleTask(index) {
  taskList[index].done = !taskList[index].done;
  displayTasks();
}
displayTasks();
