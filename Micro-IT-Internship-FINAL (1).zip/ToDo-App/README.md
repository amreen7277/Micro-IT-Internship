# 📝 To-Do List Web App

This is a simple To-Do List web app using HTML, CSS, and JavaScript.

## Features
- Add, complete, delete tasks
- Saves tasks in browser's local storage

## Run
Open `index.html` in your browser.

## Folder
```
ToDo-App/
├── index.html
├── style.css
├── script.js
```
