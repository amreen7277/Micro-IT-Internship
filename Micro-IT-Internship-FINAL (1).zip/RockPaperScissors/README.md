# ✊✋✌️ Rock Paper Scissors Game

A simple Rock-Paper-Scissors game using HTML, CSS, and JavaScript.

## Features
- Player vs Computer
- Random moves and result display

## Run
Open `index.html` in your browser.

## Folder
```
RockPaperScissors/
├── index.html
├── style.css
├── script.js
```
