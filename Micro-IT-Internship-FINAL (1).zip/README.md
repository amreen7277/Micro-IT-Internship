# 🚀 Micro IT Internship Projects

This repository contains two completed projects for the Micro IT India Internship program. Each project is simple, functional, and demonstrates key programming concepts.

---

## 📝 Project 1: To-Do List Web App

A clean and simple web application to help users manage daily tasks.

### Features:
- Add, complete, delete tasks
- Saves tasks in browser’s local storage

### Technologies:
- HTML, CSS, JavaScript

### Folder:
[ToDo-App/](./ToDo-App)

### 🌐 Live Demo:
[View To-Do App Live](https://amreen7277.github.io/Micro-IT-Internship/ToDo-App)

---

## ✊✋✌️ Project 2: Rock Paper Scissors Game

A fun interactive game where the player plays against the computer.

### Features:
- Player vs Computer mode
- Random computer moves
- Win, lose, or draw result display

### Technologies:
- HTML, CSS, JavaScript

### Folder:
[RockPaperScissors/](./RockPaperScissors)

### 🌐 Live Demo:
[View Rock Paper Scissors Live](https://amreen7277.github.io/Micro-IT-Internship/RockPaperScissors)

---

## 📂 Repository Structure
```
Micro-IT-Internship/
├── ToDo-App/
│   ├── index.html
│   ├── style.css
│   ├── script.js
│   └── README.md
├── RockPaperScissors/
│   ├── index.html
│   ├── style.css
│   ├── script.js
│   └── README.md
└── README.md (this file)
```

---

## 📌 How to Run Locally
1. Download or clone the repository.
2. Navigate to any project folder.
3. Open `index.html` in your web browser.

---

## ✨ Author
Created by **Amreen** as part of the Micro IT India Internship.

✅ Don’t forget to update your LinkedIn and tag **Micro IT India**!
